#include "GameManager.h"
#include "Character.h"
#include <iostream>

int main()
{
    GameManager gameManager;

    gameManager.RunGame();

    return 0;
}