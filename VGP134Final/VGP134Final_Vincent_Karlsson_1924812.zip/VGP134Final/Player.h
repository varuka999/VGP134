#pragma once

#include <string>

struct Player
{
	std::string name;
	int hungerLevel = 0;
};