#include <iostream>
#include "Restaurant.h"

int main()
{
	srand(time(NULL));

	Restaurant restaurant;

	restaurant.RunRestaurant();

	return 0;
}