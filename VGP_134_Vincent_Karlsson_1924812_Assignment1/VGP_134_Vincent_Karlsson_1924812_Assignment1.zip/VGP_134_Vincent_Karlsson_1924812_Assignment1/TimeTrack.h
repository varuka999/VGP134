#pragma once
#include <iostream>
#include <iomanip>

extern int timePassed;

void PrintTime();