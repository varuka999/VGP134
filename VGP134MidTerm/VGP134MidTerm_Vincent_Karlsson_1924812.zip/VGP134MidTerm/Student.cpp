#include "Student.h"

Student::Student(int mID, std::string mName)
	: id(mID), name(mName), grade(0.0f)
{
	
}
